#!/bin/sh
# e2e в headless Chrome: копия страницы с тестом в tests/.tmp (в .gitignore).
# Запуск из корня проекта: sh tests/run.sh (исходники) или sh tests/run.sh dist (собранный Личный-кабинет.html)
set -e
T=tests/.tmp; mkdir -p "$T"; cp -R src/assets "$T/"
# скрипты встраиваются в страницу: у file:// внешние скрипты прячут текст ошибок («Script error»)
python3 -I - "$T/t.html" "${1:-src}" <<'PY'
import sys
s = open("Личный-кабинет.html" if sys.argv[2] == "dist" else "src/index.html").read()
for f in ("app.js", "zk.js"):
    s = s.replace(f'<script src="assets/{f}"></script>', "<script>" + open("src/assets/" + f).read() + "</script>")
s = s.replace("</body>", "<script>" + open("tests/e2e.js").read() + "</script></body>")
open(sys.argv[1], "w").write(s)
PY
C="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
for w in 1440,900 360,740; do for rm in --force-prefers-reduced-motion ""; do
  echo "== $w ${rm:-motion}"
  "$C" --headless=new $rm --window-size=$w --virtual-time-budget=60000 --enable-logging=stderr --v=0 --dump-dom "file://$PWD/$T/t.html" 2>&1 >/dev/null \
    | grep CONSOLE | sed 's/.*CONSOLE[^"]*"//;s/", source.*//' | grep -E "FAIL|DONE|Uncaught" || echo "FAIL no output"
done; done

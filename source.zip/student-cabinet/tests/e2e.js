window.onerror = (m, u, l) => console.log("FAIL jserror " + m + " @" + l);
// headless Chrome с virtual time почти не вызывает rAF: подменяем его таймером, чтобы пружины шли и в тесте
window.requestAnimationFrame = cb => setTimeout(() => cb(performance.now()), 16);
(async () => {
  try { localStorage.clear(); } catch { }
  const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let n = 0, bad = 0;
  const ok = (c, name) => { n++; if (!c) bad++; console.log((c ? "PASS " : "FAIL ") + name); };
  const settle = () => sleep(reduced() ? 50 : 1500);
  const key = k => document.dispatchEvent(new KeyboardEvent("keydown", { key: k, code: k === "t" ? "KeyT" : "", bubbles: true }));

  // чистая логика
  const s = spring(0); s.t = 1; for (let i = 0; i < 300; i++) stepSpring(s, 300, 22, .8, 1 / 60);
  ok(s.x === 1 && s.v === 0, "spring settles on target");
  const L = lanes([{ s: 600, e: 690 }, { s: 660, e: 720 }, { s: 760, e: 850 }]);
  ok(L[0].n === 2 && L[1].lane === 1 && L[2].n === 1, "overlapping events get lanes");
  ok(eventsFor(addDays(today0(), 2)).length === 6, "busy day has 6 events");

  // вход без логина и пароля
  $("#loginForm [name=password]").value = "secret";
  $("#loginForm").requestSubmit(); await sleep(60);
  ok($("#login").hidden && !$("#app").hidden && !$("#v-home").hidden, "empty login -> home");
  ok($("#loginForm [name=password]").value === "" && !JSON.stringify(localStorage).includes("secret"), "password not kept");
  let b = $$(".dock-item");
  ok(b.length === 5 && b[2].getAttribute("aria-label") === "Главная" && b[2].getAttribute("aria-current") === "page", "dock: 5 items, home in center and active");
  ok(!document.querySelector(".dock-item .clock"), "dock: no clock in dock");
  ok($("#c-hh").textContent === String(new Date().getHours()).padStart(2, "0") && $("#c-date").textContent.length > 3 && $(".logo-dot"), "home: big clock, date, logo");
  ok(!$("#c-sec") && $("#n-title").textContent.length > 0, "home: no seconds, next lesson");
  const cr = $("#c-hh").getBoundingClientRect(), mr = $("#c-mm").getBoundingClientRect();
  ok(Math.abs(cr.top - mr.top) < 2 && mr.left > cr.right, "home: time is horizontal");
  ok($$("#bg .orb").length >= 10, "background: orbs rendered");
  const o0 = $("#bg .orb").style.transform; await sleep(reduced() ? 50 : 400);
  ok(reduced() ? $("#bg .orb").style.transform === o0 : $("#bg .orb").style.transform !== o0, "background: orbs drift (still with reduced motion)");

  // поиск
  $("#s-open").click(); await settle();
  ok(!$("#search").hidden && document.activeElement === $("#s-input") && $$("#s-list .s-it").length > 0, "search: opens with suggestions");
  const typeQ = async q => { $("#s-input").value = q; $("#s-input").dispatchEvent(new Event("input")); await sleep(20); };
  await typeQ("петров");
  ok($$("#s-list .s-g").some(g => g.textContent === "Преподаватели") && $("#s-list mark"), "search: teacher found, match highlighted");
  await typeQ("ъъъжжж");
  ok($("#s-list .s-empty"), "search: empty state");
  await typeQ(",fps"); // «базы» в английской раскладке
  ok($("#s-list .s-it b")?.textContent.includes("Базы данных"), "search: wrong keyboard layout is fixed");
  await typeQ("справка обуч");
  ok($("#s-list .s-it b").textContent === "Справка об обучении", "search: certificate found");
  $("#s-input").dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true })); await sleep(80);
  await sleep(700);
  ok($("#search").hidden && !$("#v-zk").hidden && $('.gm-it[data-id="study"].open'), "search: Enter opens the certificate order");
  window.ZK.closeSheet(); await sleep(700);
  b[2].click(); await sleep(30);
  $("#s-open").click(); await settle();
  $("#s-input").dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); await settle();
  ok($("#search").hidden && !$("#v-home").hidden, "search: Escape closes");

  // док: клавиатура
  b[2].focus();
  b[2].dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowRight", bubbles: true }));
  ok(document.activeElement === b[3], "dock: arrow moves focus");

  // разделы из шаблона
  b[1].click(); await sleep(30);
  ok(!$("#v-zk").hidden && $$("#zk-main .subj").length > 3 && b[1].getAttribute("aria-current") === "page", "study: grades from template");
  ok($("#zk-main .gr-ring .ring") && $$("#zk-main .hm i").length > 90 && $$("#zk-main .hm i.m, #zk-main .hm i.p").length > 0, "study: rating ring and attendance map");
  { const r = $("#zk-main .gr-ring").textContent;
    ok(r.includes("из 100") && !r.includes("Место в группе") && !r.includes("%") && !$("#zk-main").textContent.includes("Доля баллов") && !$("#zk-main").textContent.includes("Шкала: 61"), "study: 100-point average, no group place or hints"); }
  ok(reduced() || $$("#zk-main .view > *").some(k => k.getAnimations().length), "page change animates the new screen in");
  ok(!$("#zk-main .subj.open") && $("#zk-main .subj .scale .tick"), "study: subjects collapsed with scale");
  $('#zk-main .subj-h[data-i="1"]').click(); await sleep(20);
  ok($('#zk-main .subj.open .recs li') && $$("#zk-main .subj.open .recs li").length >= 2 && $("#zk-main .subj.open .recs").textContent.includes("КР № 2"), "study: expanded subject shows recommendations");
  $('#zk-main [data-action="gtab"][data-t="session"]').click(); await sleep(20);
  ok($("#zk-main .timeline") && [...$$("#zk-main .card-h h2")].some(h => h.textContent === "Стипендия"), "study: scholarship for budget student");
  $('#zk-main [data-action="gtab"][data-t="record"]').click(); await sleep(20);
  ok($("#zk-main table.record") && /^\d{2,3}$/.test($("#zk-main table.record .mark-cell").textContent) && $("#zk-main table.record").textContent.includes("отлично"), "study: record book in 100 points");
  b[3].click(); await sleep(30);
  ok(b[3].getAttribute("aria-label") === "Профиль" && b[3].getAttribute("aria-current") === "page" && $("#zk-main .idcard") && !$("#zk-main .swatches"), "dock: profile instead of docs");
  ok($$("#zk-main .pf-doc").length === 3 && $$("#zk-main .pf-pane").length === 3, "profile: docs buttons and three info windows");
  ok($$("#zk-main .pf-pane")[1].textContent.includes("Пароль от почты") && $$("#zk-main .pf-pane")[2].textContent.includes("Мобильный телефон"), "profile: personal and contacts windows");
  const eye = $('#zk-main [data-action="pfeye"]'), k0 = eye.dataset.k;
  ok($("#zk-main .pf-v.masked"), "profile: secrets masked");
  eye.click(); await sleep(20);
  ok($(`#zk-main [data-action="pfeye"][data-k="${k0}"][aria-pressed="true"]`), "profile: eye reveals value");
  $('#zk-main [data-action="pftab"][data-i="2"]').click(); await sleep(20);
  ok($('#zk-main [data-action="pftab"][data-i="2"][aria-pressed="true"]'), "profile: switch to contacts window");
  $('#zk-main .pf-doc:not([data-k])').click(); await sleep(60);
  ok($("#zk-main h1").textContent === "Документы" && !$(".gm") && b[3].getAttribute("aria-current") === "page", "profile: Документы opens documents page");
  $("#zk-main [data-back]").click(); await sleep(30);
  $('#zk-main .pf-doc[data-k="cert"]').click(); await sleep(700);
  ok(b[3].getAttribute("aria-current") === "page" && $("#zk-main h1").textContent === "Документы" && $('.gm[data-k="cert"]'), "profile: Справки -> documents + order window");
  const nReq = $$("#zk-main .req").length;
  ok($$("#zk-main .docs-act").length === 3 && nReq > 0, "docs: three buttons and my requests");
  ok($$(".gm .gm-it").length === 4 && $("#gmQ"), "picker: certificates list and search");
  $("#gmQ").value = "воен"; $("#gmQ").dispatchEvent(new Event("input", { bubbles: true })); await sleep(20);
  ok($$(".gm .gm-it:not([hidden])").length === 1 && $(".gm .gm-it.open"), "picker: search filters and opens the only hit");
  $("#gmQ").value = ""; $("#gmQ").dispatchEvent(new Event("input", { bubbles: true }));
  $('.gm-row[data-id="study"]').click(); await sleep(30);
  ok($('.gm-it[data-id="study"].open') && !$('.gm-it[data-id="army"].open'), "picker: row expands details");
  $('.gm-it[data-id="study"] .gm-form').requestSubmit(); await sleep(700);
  ok(!$(".gm") && $$("#zk-main .req").length === nReq + 1 && $(".toast"), "docs: order adds a request");
  $('#zk-main [data-action="picker"][data-k="app"]').click(); await sleep(700);
  $('.gm-row[data-id="aid"]').click(); await sleep(30);
  $('.gm-it[data-id="aid"] .gm-form').requestSubmit(); await sleep(30);
  ok($('.gm-it[data-id="aid"] .err:not([hidden])'), "picker: application needs a reason");
  document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" })); await sleep(700);
  ok(!$(".gm") && $('#zk-main [data-action="picker"][data-k="app"]').style.visibility === "", "picker: Esc closes back into button");
  $('#zk-main [data-action="picker"][data-k="archive"]').click(); await sleep(700);
  ok($$(".gm .gm-it").length >= 1 && $(".gm-it .gm-body .req"), "archive: issued documents");
  document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" })); await sleep(700);
  b[4].click(); await sleep(30);
  ok($('#zk-main [data-action="itab"][data-t="chat"][aria-pressed="true"]') && $$("#zk-main .ms-it").length === 5, "inbox: messenger with chat list");
  ok($("#zk-main .ms-it .ms-badge"), "inbox: unread counters");
  $('#zk-main [data-action="chat"][data-id="curator"]').click(); await sleep(30);
  ok($("#zk-main .ms-name b").textContent.includes("Лебедева") && !$('#zk-main [data-id="curator"] .ms-badge') && getComputedStyle($("#zk-main .ms-chat")).display !== "none", "inbox: open chat marks it read");
  const nMsg = $$("#chat .msg").length;
  $("#chatInput").value = "Тест"; $("#composer").requestSubmit(); await sleep(30);
  ok($$("#chat .msg").length === nMsg + 1 && $("#chat .msg.me:last-child").textContent.includes("Тест"), "inbox: chat sends message");
  await sleep(2600);
  ok($$("#chat .msg").length === nMsg + 2 && !$("#chat .typing"), "inbox: auto reply after typing");
  $('#zk-main [data-action="chatinfo"]').click(); await sleep(30);
  ok($(".sheet .kv"), "inbox: contact info"); window.ZK.closeSheet();
  if (innerWidth < 760) { $('#zk-main [data-action="chatback"]').click(); await sleep(20); ok(getComputedStyle($("#zk-main .ms-list")).display !== "none", "inbox: back to chat list on phone"); }
  $('#zk-main [data-action="itab"][data-t="notes"]').click(); await sleep(20);
  ok($$("#zk-main .note-item").length > 0, "inbox: news tab");
  $('#zk-main [data-action="itab"][data-t="chat"]').click(); await sleep(20);
  if ($("#zk-main .ms").dataset.open === "1" && innerWidth < 760) { $('#zk-main [data-action="chatback"]').click(); await sleep(20); }
  const mq = $("#msQ"); mq.value = "ким"; mq.dispatchEvent(new Event("input", { bubbles: true })); await sleep(20);
  ok($('#msItems [data-action="person"][data-id="s-kim"]') && !$('#msItems [data-id="dean"]'), "messenger search: finds a student, filters chats");
  $('#msItems [data-action="person"][data-id="s-kim"]').click(); await sleep(30);
  ok($("#zk-main .ms-name b").textContent.includes("Ким") && $("#chat .ms-hello") && $$("#zk-main .ms-list .ms-it").length === 6, "messenger search: opens a new chat with the person");
  if (innerWidth < 760) { $('#zk-main [data-action="chatback"]').click(); await sleep(20); }
  const mq2 = $("#msQ"); mq2.value = "сеть"; mq2.dispatchEvent(new Event("input", { bubbles: true })); await sleep(20);
  ok($('#msItems [data-id="t-safina"]'), "messenger search: word stems (сеть -> сети)");
  mq2.value = "gtnhjd"; mq2.dispatchEvent(new Event("input", { bubbles: true })); await sleep(20);
  ok($('#msItems [data-id="petrov"]'), "messenger search: wrong keyboard layout");
  mq2.value = ""; mq2.dispatchEvent(new Event("input", { bubbles: true })); await sleep(20);
  $('#zk-main [data-action="mskind"][data-k="teacher"]').click(); await sleep(20);
  ok($$('#msItems [data-action="person"]').length === 8 && $("#msItems .avatar.teacher"), "messenger: teachers directory");
  $('#zk-main [data-action="mskind"][data-k="chats"]').click(); await sleep(20);
  $('#zk-main [data-action="itab"][data-t="events"]').click(); await sleep(20);
  ok($$("#zk-main .evb").length === 9 && $("#zk-main .evb.hero") && $("#zk-main .chip.joint"), "events: board with joint events");
  const eg = $('#zk-main .evb [data-action="evgo"]'), eid = eg.dataset.id; eg.click(); await sleep(20);
  ok(window.lkMy.has("ev-" + eid) && $(`#zk-main [data-action="evgo"][data-id="${eid}"]`).getAttribute("aria-pressed") === "true", "events: going adds it to the schedule");
  $('#zk-main [data-action="evf"][data-k="mine"]').click(); await sleep(20);
  ok($$("#zk-main .evb").length === 1, "events: my events filter");
  $('#zk-main [data-action="evmore"]').click(); await sleep(30);
  ok($(".sheet .kv") && $('.sheet [data-action="evgo"]'), "events: details sheet"); window.ZK.closeSheet();
  $("#zk-main [data-back]").click(); await sleep(30);
  ok($("#zk-main h1").textContent === "Документы", "back: inbox -> documents");
  $("#zk-main [data-back]").click(); await sleep(30);
  ok($("#zk-main .pf-info"), "back: documents -> profile");
  b[2].click(); await sleep(30);
  ok(!$(".avatar-btn"), "home: no profile button in corner");
  $(".set-btn").click(); await sleep(30);
  ok(!$("#v-zk").hidden && $('#zk-main [data-action="pref"]') && $('#zk-main [data-action="logout"]') && !$("#zk-main .idcard"), "home: settings in corner");
  const R = document.documentElement;
  ok($("#zk-main .look .theme-sw") && $$("#zk-main .clock-pick button").length === 3 && $("#glassRng"), "settings: appearance card");
  $('#zk-main [data-action="theme"][data-v="dark"]').click(); await sleep(20);
  ok(R.dataset.scheme === "dark" && getComputedStyle(R).colorScheme === "dark", "settings: dark theme");
  $('#zk-main [data-action="theme"][data-v="auto"]').click(); await sleep(20);
  ok(R.dataset.theme === "auto" && R.dataset.scheme === (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"), "settings: auto theme follows system");
  $('#zk-main [data-action="theme"][data-v="light"]').click(); await sleep(20);
  const rng = $("#glassRng"); rng.value = 20; rng.dispatchEvent(new Event("input", { bubbles: true })); await sleep(20);
  ok(R.style.getPropertyValue("--g") === "0.20" && $("#glassVal").textContent === "20%", "settings: glass slider");
  rng.value = 70; rng.dispatchEvent(new Event("input", { bubbles: true }));
  $('#zk-main [data-action="clockst"][data-v="stack"]').click(); await sleep(20);
  ok(R.dataset.clock === "stack", "settings: clock style");
  $('#zk-main [data-action="clockst"][data-v="classic"]').click();
  $('#zk-main [data-action="bgpick"][data-v="mint"]').click(); await sleep(20);
  const wf = R.style.getPropertyValue("--wf");
  ok(R.dataset.bg === "mint" && wf && wf !== "255,255,255" && $('#zk-main [data-action="bgpick"][data-v="mint"]').getAttribute("aria-checked") === "true", "settings: background + glass tint");
  $('#zk-main [data-action="uipref"][data-k="tint"]').click(); await sleep(20);
  ok(!R.style.getPropertyValue("--wf"), "settings: glass tint can be off");
  $('#zk-main [data-action="uipref"][data-k="tint"]').click();
  $('#zk-main [data-action="bgpick"][data-v="plain"]').click(); await sleep(20);
  ok(getComputedStyle($("#bg .orb")).display === "none", "settings: plain background hides orbs");
  const cv = document.createElement("canvas"); cv.width = cv.height = 40; const c2 = cv.getContext("2d"); c2.fillStyle = "#c04040"; c2.fillRect(0, 0, 40, 40);
  const blob = await new Promise(r => cv.toBlob(r, "image/png"));
  await window.lkUI.setPhoto(new File([blob], "a.png", { type: "image/png" })); await sleep(20);
  ok(R.dataset.bg === "photo" && window.lkUI.photo().rgb[0] > 150 && $("#bg").style.backgroundImage.startsWith("url("), "settings: own photo, tint taken from it");
  window.lkUI.set("bg", "spheres"); window.ZK.show("settings"); await sleep(20);
  $('#zk-main [data-action="access"]').click(); await sleep(30);
  ok($$("#zk-main .dk-row").length === 5 && $("#zk-main h1").textContent === "Универсальный доступ", "access: dock editor");
  $('#zk-main [data-action="dkon"][data-k="study"]').click(); await sleep(30);
  ok($$("#dock .dock-item").length === 4 && !$('#dock [aria-label="Учёба"]'), "access: hide dock item");
  $('#zk-main [data-action="dkmove"][data-id="inbox"][data-d="-1"]').click(); await sleep(30);
  ok($$("#dock .dock-item")[2].getAttribute("aria-label") === "Уведомления", "access: reorder dock");
  $('#zk-main [data-action="dkicon"][data-id="home"][data-n="1"]').click(); await sleep(30);
  ok($('#dock [aria-label="Главная"] circle'), "access: change icon");
  $('#zk-main [data-action="uipref"][data-k="calm"]').click(); await sleep(20);
  ok(R.classList.contains("calm"), "access: less motion");
  $('#zk-main [data-action="uipref"][data-k="calm"]').click();
  $('#zk-main [data-action="dkreset"]').click(); await sleep(30);
  ok($$("#dock .dock-item").length === 5 && $$("#dock .dock-item")[2].getAttribute("aria-label") === "Главная", "access: reset dock");
  b = $$(".dock-item");   // док пересобран — берём новые кнопки
  $("#zk-main [data-back]").click(); await sleep(30);
  $("#zk-main [data-back]").click(); await sleep(30);
  ok(!$("#v-home").hidden && $("#v-zk").hidden, "home again");

  // календарь
  b[0].click(); await settle();
  const def = innerWidth < 760 ? 3 : 2;
  ok(!$("#v-schedule").hidden && cal.level === def && $(".lvl.on " + (def === 3 ? ".dy" : ".wk")), "dock -> schedule, day on phone / week on desktop");
  ok($("#v-schedule [data-back]"), "schedule: back button");
  ok($$(".seg button")[0].textContent === "День" && $(".side.l") && $(".side.r"), "segments start with Day, side switchers present");
  const names = ["yr", "mo", "wk", "dy"];
  for (let z = 0; z < 4; z++) {
    $(`.seg [data-z="${z}"]`).click(); await settle();
    if (cal.level !== z) console.log("FAIL dbg z=" + cal.Z.x + " t=" + cal.Z.t + " v=" + cal.Z.v + " lvl=" + cal.level);
    ok(cal.level === z && $$(".lvl.on").length === 1 && $(".lvl.on ." + names[z]), "switch -> level " + z);
  }
  const t0 = $("#cal-title").textContent; $("#cal-next").click(); await sleep(30);
  ok($("#cal-title").textContent !== t0, "next changes period");
  key("t"); await sleep(30);
  ok($("#cal-title").textContent === t0, "T returns to today");
  key("+"); await settle();
  ok(cal.level === 4 && $(".lvl.on .hr"), "+ -> hour level");
  key("+"); await settle(); ok(cal.level === 4, "zoom clamps at hour");
  key("-"); await settle(); key("-"); await settle();
  ok(cal.level === 2, "- twice -> week");
  $('.seg [data-z="1"]').click(); await settle();
  const cell = $('.lvl.on .day[data-date="' + dkey(addDays(today0(), 2)) + '"]') || $(".lvl.on .day:not(.dim)");
  const r = cell.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  const pe = (type, x, y, id = 1) => $("#cal-stage").dispatchEvent(new PointerEvent(type, { clientX: x, clientY: y, pointerId: id, isPrimary: id === 1, bubbles: true, button: 0, pointerType: "touch" }));
  pe("pointerdown", cx, cy); pe("pointerup", cx, cy); await settle();
  ok(cal.level === 3 && dkey(cal.F) === cell.dataset.date && $(".lvl.on .ag-card"), "tap month cell -> day of that date");
  ok($$("#cal-strip .sd").length === 7 && !$("#cal-strip").hidden && $("#cal-strip .sd.sel").dataset.date === dkey(cal.F), "day: week strip, selected day");
  ok($(".lvl.on .tag.warn") && $(".lvl.on .ag-gap"), "day: breaks and overlap shown");
  const d0 = cal.F;
  $("#cal-next").click(); await sleep(30);
  ok(dkey(cal.F) === dkey(addDays(d0, 1)) && $$(".lvl.on").length === 1, "side switcher -> next day, ghost is separate");
  const sd = $$("#cal-strip .sd")[0];
  sd.dispatchEvent(new PointerEvent("pointerdown", { clientX: 5, bubbles: true })); sd.dispatchEvent(new PointerEvent("pointerup", { clientX: 5, bubbles: true })); await sleep(30);
  ok(dkey(cal.F) === sd.dataset.date && $("#cal-strip .sd.sel") === sd, "strip tap selects the day");
  jumpTo(addDays(today0(), 2)); await settle();
  const cr2 = $(".lvl.on .ag-card").getBoundingClientRect();
  pe("pointerdown", cr2.left + 30, cr2.top + 20); pe("pointerup", cr2.left + 30, cr2.top + 20); await sleep(60);
  ok($("#sheetRoot .sheet") && $("#sheetRoot .kv"), "tap lesson -> details sheet");
  $('#sheetRoot [data-action="closesheet"]').click(); await sleep(30);
  const d1 = cal.F, sr0 = $("#cal-stage").getBoundingClientRect(), y0 = sr0.top + 40;
  pe("pointerdown", sr0.left + 250 > sr0.right ? sr0.right - 20 : sr0.left + 250, y0);
  for (let x = 0; x <= 140; x += 20) { pe("pointermove", sr0.left + 250 - x, y0); await sleep(16); }
  ok($(".lvl.on").style.transform.includes("translateX(-"), "swipe: view follows the finger");
  pe("pointerup", sr0.left + 110, y0); await settle();
  ok(dkey(cal.F) === dkey(addDays(d1, 1)), "swipe left -> next day");
  $('.seg [data-z="2"]').click(); await settle();
  ok($$(".lvl.on .wcol").length === 7 && (innerWidth >= 760 || $(".lvl.on .wcol").getBoundingClientRect().width > innerWidth * .8), "week: list of days on phone");
  $('.seg [data-z="3"]').click(); await settle();
  // долгое нажатие на пустое место -> своё занятие
  $(".lvl.on .lp-hint").scrollIntoView({ block: "center" }); await sleep(30);
  const hr = $(".lvl.on .lp-hint").getBoundingClientRect();
  pe("pointerdown", hr.left + hr.width / 2, hr.top + 4); await sleep(650);
  ok($("#myEv") && $("#my-d").value === dkey(cal.F), "long press on empty space -> new lesson form");
  pe("pointerup", hr.left + hr.width / 2, hr.top + 4); await sleep(30);
  ok($("#myEv"), "long press: release does not count as tap");
  $("#myEv").requestSubmit(); await sleep(20);
  ok($("#myEv .err:not([hidden])"), "new lesson: title required");
  $("#my-t").value = "Тест-занятие"; $("#myEv").requestSubmit(); await sleep(60);
  ok(!$("#myEv") && $$(".lvl.on .ag-card.own").some(c => c.textContent.includes("Тест-занятие")), "new lesson appears in the day");
  const own = $$(".lvl.on .ag-card.own").find(c => c.textContent.includes("Тест-занятие")); own.scrollIntoView({ block: "center" }); await sleep(30);
  const orr = own.getBoundingClientRect(); pe("pointerdown", orr.left + 30, orr.top + 15); pe("pointerup", orr.left + 30, orr.top + 15); await sleep(60);
  $('#sheetRoot [data-cal="del"]').click(); await sleep(60);
  ok(!$$(".lvl.on .ag-card.own").some(c => c.textContent.includes("Тест-занятие")), "own lesson can be deleted");
  // щипок двумя пальцами: разводим — глубже
  const sr = $("#cal-stage").getBoundingClientRect(), mx = sr.left + sr.width / 2, my = sr.top + sr.height / 2;
  pe("pointerdown", mx - 40, my, 1); pe("pointerdown", mx + 40, my, 2);
  for (let d = 40; d <= 120; d += 10) { pe("pointermove", mx - d, my, 1); pe("pointermove", mx + d, my, 2); await sleep(16); }
  pe("pointerup", mx - 120, my, 1); pe("pointerup", mx + 120, my, 2); await settle();
  ok(cal.level === 4, "pinch out -> deeper level");
  // ctrl+колесо: отдаляем
  for (let i = 0; i < 12; i++) { $("#cal-stage").dispatchEvent(new WheelEvent("wheel", { deltaY: 20, ctrlKey: true, clientX: mx, clientY: my, bubbles: true, cancelable: true })); await sleep(16); }
  await sleep(250); await settle();
  ok(cal.level < 4, "ctrl+wheel zooms out");
  ok(document.documentElement.scrollWidth <= innerWidth, "no horizontal scroll");
  ok(getComputedStyle($(".lvl.on button") || $(".lvl.on")).touchAction === "pan-y" && getComputedStyle($(".dock-item")).touchAction === "none", "touch: swipes over cards and dock scrub are not taken by the browser");
  window.lkGo("settings"); await sleep(30);
  ok($("#zk-main").innerHTML.includes("Выставление баллов") && !$("#zk-main").innerHTML.includes("Бухгалтерия"), "access log: accounting entry removed");
  { window.lkGo("schedule"); await sleep(30); const c = $(".lvl.on .cell");
    if (c) { const r = c.getBoundingClientRect(); $("#cal-stage").dispatchEvent(new PointerEvent("pointermove", { pointerType: "mouse", clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, bubbles: true })); await sleep(60); }
    ok(!c || (reduced() ? !c.style.scale : +c.style.getPropertyValue("--wv") > .9 && c.style.scale), "calendar: wave lifts cells under the pointer");
    $("#cal-stage").dispatchEvent(new PointerEvent("pointerleave", { pointerType: "mouse" })); await sleep(60);
    ok(!c || !c.style.scale, "calendar: wave settles when pointer leaves"); }
  dispatchEvent(new Event("scroll")); ok(!$("#dock").classList.contains("shrunk"), "dock does not change on scroll");
  console.log(`DONE ${n - bad}/${n}`);
})();
